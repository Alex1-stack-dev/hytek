const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { exportCSV, exportHY3, exportEV3 } = require('./reporting');
const app = express();
app.use(bodyParser.json());
app.use(cors());

// Sample endpoints for results, scoreboard, export
let results = [
  { athlete: "John S.", time: "55.98", place: 1, points: 5 },
  { athlete: "Amy T.", time: "57.12", place: 2, points: 4 }
];
let scoreboard = [
  { lane: 1, athlete: "John S.", time: "55.98", place: 1 },
  { lane: 2, athlete: "Amy T.", time: "57.12", place: 2 }
];

app.get('/api/results/:meet', (req, res) => res.json(results));
app.get('/api/scoreboard/:meet', (req, res) => res.json(scoreboard));

// Export endpoints (simulate file download)
app.get('/api/export/csv', (req, res) => {
  const file = exportCSV(results);
  res.type('text/csv').send(file);
});
app.get('/api/export/hy3', (req, res) => {
  const file = exportHY3(results);
  res.type('text/plain').send(file);
});
app.get('/api/export/ev3', (req, res) => {
  const file = exportEV3(results);
  res.type('text/plain').send(file);
});

// Hardware simulation endpoints could go here...

app.listen(3000, () => console.log('Backend running on http://localhost:3000'));