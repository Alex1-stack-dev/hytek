// Simulated protocol handler for Time Machine G2
module.exports = function connectTimeMachineG2(portName, onData) {
  // Use node-serialport to connect and parse packets
};