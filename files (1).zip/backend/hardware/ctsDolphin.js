// Simulated protocol handler for CTS Dolphin
module.exports = function connectCTS(portName, onData) {
  // Use node-serialport to connect and parse packets
};