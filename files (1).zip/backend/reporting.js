function exportCSV(results) {
  return "Athlete,Time,Place,Points\n" + results.map(r =>
    `${r.athlete},${r.time},${r.place},${r.points}`
  ).join("\n");
}
function exportHY3(results) {
  // Simulated format for demo
  return "HY3 DATA EXAMPLE";
}
function exportEV3(results) {
  // Simulated format for demo
  return "EV3 DATA EXAMPLE";
}
module.exports = { exportCSV, exportHY3, exportEV3 };