import React, { useState } from "react";
export default function TimingConsoleMenu() {
  const [logs, setLogs] = useState([]);
  function connect(system) {
    setLogs([...logs, `Connected to ${system} (simulated)`]);
  }
  return (
    <div>
      <h2>Timing Console</h2>
      <button onClick={() => connect("CTS Dolphin")}>CTS Dolphin</button>
      <button onClick={() => connect("CTS Touchpads")}>CTS Touchpads</button>
      <button onClick={() => connect("Daktronics")}>Daktronics</button>
      <button onClick={() => connect("Time Machine G2")}>Time Machine G2</button>
      <ul>{logs.map((log, idx) => <li key={idx}>{log}</li>)}</ul>
    </div>
  );
}