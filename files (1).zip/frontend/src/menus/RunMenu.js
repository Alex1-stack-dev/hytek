import React from "react";
export default function RunMenu() {
  // Add your live results grid, DQ, scoring, etc.
  return <div><h2>Run Meet</h2></div>;
}